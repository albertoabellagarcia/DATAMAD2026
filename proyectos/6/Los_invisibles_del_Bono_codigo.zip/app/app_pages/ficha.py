import altair as alt
import numpy as np
import pandas as pd
import streamlit as st

from datos import BLUE, RES, SLOT1, SLOT2, SOURCE, es, municipalities, pct, query, result

PROGRAMMES = {"bono_alquiler_joven": "Bono Alquiler Joven", "ayudas_alquiler_jovenes": "Ayudas al alquiler para jóvenes",
              "ayudas_alquiler_escasos_recursos": "Ayudas al alquiler, escasos recursos"}


@st.cache_data(show_spinner=False)
def art135():
    """The base of the art. 135 study, one row per municipality (scripts/estudio_art135.py)."""
    return pd.read_csv(RES / "estudio_art135.csv", dtype={"ine": str}).set_index("ine")


def rent_chart(rent, caps):
    """Median rent with its p25-p75 band (SERPAVI) and today's and the Plan's caps as dashed lines."""
    x = alt.X("anio:O", title=None, axis=alt.Axis(labelAngle=0))
    band = alt.Chart(rent).mark_area(color=BLUE[1], opacity=0.5).encode(
        # Spanish thousands: «1.200», not the «1,200» of the chart library (seen 17-nov on the axis)
        x=x, y=alt.Y("p25:Q", title="€ al mes", axis=alt.Axis(format=",.0f", labelExpr="replace(datum.label, ',', '.')")),
        y2="p75:Q")
    line = alt.Chart(rent).mark_line(color=SLOT1, strokeWidth=2, point=alt.OverlayMarkDef(size=60, filled=True)).encode(
        x=x, y="mediana:Q",
        tooltip=[alt.Tooltip("anio:O", title="Año"), alt.Tooltip("mediana:Q", title="Mediano (€)", format=".0f"),
                 alt.Tooltip("p25:Q", title="Uno de cada cuatro paga menos de (€)", format=".0f"),
                 alt.Tooltip("p75:Q", title="Uno de cada cuatro paga más de (€)", format=".0f")])
    rules = alt.Chart(caps).mark_rule(strokeDash=[6, 4], strokeWidth=2).encode(
        y="tope:Q", color=alt.Color("nombre:N", title=None, scale=alt.Scale(range=[SLOT2, "#8a8a8a"]),
                                    legend=alt.Legend(orient="top")),
        tooltip=[alt.Tooltip("nombre:N", title="Tope"), alt.Tooltip("tope:Q", title="€ al mes", format=".0f")])
    return (band + line + rules).properties(height=300)

t = municipalities()
options = sorted(t["municipio"], key=lambda n: n.lower())
st.session_state.setdefault("municipio", "Parla")
name = st.selectbox("Municipio", options, key="municipio", bind="query-params")
r = t.set_index("municipio").loc[name]
rest = t[t["ine"] != "079"]
rest_rate = 1000 * rest["bono_aceptadas"].sum() / rest["jovenes_20_34_2022"].sum()

st.title(name)
# 26-nov: the need level in its colour (alta red, media orange, baja green), as the gauge under the index below
LEVEL = {"alta": ("red", "#e03131"), "media": ("orange", "#f08c00"), "baja": ("green", "#2f9e44")}
level = next((k for k in LEVEL if str(r["grupo_necesidad"]).endswith(k)), None)
if isinstance(r["grupo_necesidad"], str):
    st.badge(r["grupo_necesidad"].capitalize(), icon=":material/group:", color=LEVEL[level][0] if level else "blue")

# 26-nov: the diagnosis first, in the same row and height as before: need (with its gauge), the rents above the Plan's cap
# (orange) and the cap of the proposal (green), the same figures as the table below; the 2022 figures go after it
with st.container(horizontal=True, key="ficha_cifras"):  # key: only for the style of these cards (streamlit_app.py)
    st.metric("Índice de necesidad (0-100)", es(r["indice_necesidad"]), border=True, height="stretch")
    st.metric("Alquileres de 2024 por encima del tope del Plan",
              "—" if np.isnan(r["fuera_plan"]) else pct(r["fuera_plan"]), border=True, height="stretch")
    st.metric("Tope del piso con la propuesta", es(r["tope_propuesta"]) + " €", border=True, height="stretch")
    st.metric("Jóvenes de 20 a 34 años (2024)", es(r["jovenes_20_34_2024"]), border=True, height="stretch")

st.subheader(f"El tope y el alquiler en {name}")  # 24-nov: the name on screen too, where the demo scrolls to
if np.isnan(r["serpavi_p25_2024"]):
    st.info("El SERPAVI no da alquileres de 2024 para este municipio, así que no se puede medir qué parte supera el tope.",
            icon=":material/info:")
else:
    st.caption(f"Alquiler mediano de 2024: {es(r['serpavi_med_2024'])} € al mes; uno de cada cuatro pasa de "
               f"{es(r['serpavi_p75_2024'])} € (SERPAVI).")
    rows = [("Bono 2022", r["tope_2022"], r["share_above_tope_2022_en_2024"]),
            ("Bono 2024 (hoy)", r["tope_2024"], r["share_above_tope_2024_en_2024"]),
            ("Plan 2026-2030", r["tope_plan"], r["fuera_plan"]),
            ("Propuesta: Plan o alquiler local, hasta 1.000 €", r["tope_propuesta"], r["fuera_propuesta"])]
    # 24-nov: the Plan's row and the proposal's, in bold and in the slides' colours (orange and green; Markdown colours
    # follow the light and dark themes): they are the two rows the demo points at
    hl = {2: "orange", 3: "green"}

    def cell(i, s):
        return f":{hl[i]}[**{s}**]" if i in hl else s

    st.table({"Regla": [cell(i, x[0]) for i, x in enumerate(rows)],
              "Tope del piso": [cell(i, es(x[1]) + " €") for i, x in enumerate(rows)],
              "Alquileres de 2024 por encima": [cell(i, pct(x[2]) if not np.isnan(x[2]) else "—")
                                                for i, x in enumerate(rows)]},
             alt=f"Topes del Bono en {name} y parte del alquiler de 2024 que los supera")
    st.caption(f"Tres jóvenes que comparten piso con contratos de habitación pueden pagar entre los tres hasta "
               f"{es(1.5 * r['tope_2024'])} € (3 × {es(r['tope_2024'] / 2)} €). Con ese límite queda fuera el "
               f"{pct(r['fuera_3_comparten_hoy'])} de los alquileres de 2024, si la habitación cuesta el alquiler del piso "
               f"entre tres (el caso optimista).")
    if r["ine"] == "079":  # one cap for the whole city, but rents go from Puente de Vallecas to Chamberí
        st.page_link("app_pages/donde.py", icon=":material/explore:",
                     label="Madrid tiene 21 distritos y el alquiler cambia mucho entre ellos: míralos uno a uno en "
                           "«¿Dónde me llega?»")
study = art135()
if r["ine"] in study.index and study.loc[r["ine"], "sube_tope"]:  # a village where the proposal lifts the Plan's 500 EUR
    a, threshold = study.loc[r["ine"]], result("estudio_art135")["cpi"]["threshold_b_pct"]
    lift = f"La propuesta sube aquí el tope de {es(a['tope_plan'])} € a {es(a['tope_propuesta'])} €"
    rise = f"el alquiler mediano del SERPAVI subió un {es(a['subida_alquiler_pct'], 1)} % de 2019 a 2024"
    # art. 135 asks for a study of the rental offer, which "podrá fundamentarse" on the cases of Ley 12/2023, art. 18.3
    offer = (None if pd.isna(a["parte_por_encima_tope_plan"]) else
             f"con el tope del Plan queda fuera el {pct(a['parte_por_encima_tope_plan'])} del alquiler de 2024")
    met_offer = str(a["cumple_oferta"]) == "True"  # True, False or empty in the CSV
    reasons = [f"{offer}, más de la mitad (es la oferta, lo que pide el artículo)"] if met_offer else []
    if a["justificacion"] in ("b", "a y b"):
        reasons.append(f"{rise}, más que el IPC + 3 puntos ({es(threshold, 1)} %; Ley 12/2023, art. 18.3 b)")
    if a["justificacion"] in ("a", "a y b"):
        reasons.append("el alquiler pasa del 30 % de la renta del hogar (Ley 12/2023, art. 18.3 a)")
    if reasons:
        st.success(f"**{lift}**, y la base del estudio del art. 135 lo apoya: {'; y '.join(reasons)}. Decidirlo y "
                   "acordarlo con el Ministerio le toca a la Comunidad.", icon=":material/gavel:")
    elif a["justificacion"] == "ninguno":
        st.info(f"**{lift}**, pero con estos datos la base del estudio del art. 135 no lo apoya: {offer}, menos de la "
                f"mitad, y {rise} (hacía falta un {es(threshold, 1)} %).", icon=":material/gavel:")
    else:
        st.info(f"**{lift}**. Para apoyarlo en el art. 135 faltan datos: el SERPAVI tiene aquí menos de 30 viviendas en "
                "alquiler en 2019 o en 2024" + (f" ({offer}, menos de la mitad)." if offer else "."),
                icon=":material/gavel:")

with st.container(horizontal=True):  # 26-nov: moved here from the top row, unchanged
    st.metric("Solicitudes del Bono 2022 por 1.000 jóvenes", es(r["solicitudes_1000_2022"], 1), border=True,
              height="stretch")
    st.metric("Bonos 2022 por 1.000 jóvenes", es(r["cobertura_2022"], 1), border=True, height="stretch",
              help=f"En el resto de la Comunidad sin Madrid capital: {es(rest_rate, 1)}. Sin dato si hay menos de 500 jóvenes.")

left, right = st.columns([3, 2], gap="large")
with left:
    st.subheader("El alquiler, año a año")
    rent = query("SELECT anio, mediana, p25, p75 FROM alquiler_serpavi WHERE ine = ? AND mediana IS NOT NULL "
                 "ORDER BY anio", (r["ine"],))
    caps = query("SELECT regla, tope_piso AS tope FROM topes WHERE ine = ? AND regla IN ('bono_2024', 'plan_2026_2030')",
                 (r["ine"],))
    caps["nombre"] = caps["regla"].map({"bono_2024": "Tope del Bono hoy", "plan_2026_2030": "Tope del Plan 2026-2030"})
    if len(rent) < 2:
        st.caption("El SERPAVI no tiene una serie de alquileres para este municipio.")
    else:
        st.altair_chart(rent_chart(rent, caps.sort_values("regla")),
                        alt=f"Alquiler mensual mediano en {name} de {rent['anio'].min()} a {rent['anio'].max()}, con "
                            f"los topes del Bono y del Plan")
        st.caption("Línea: alquiler mensual mediano de vivienda colectiva. Banda: la mitad central de los alquileres "
                   "(del p25 al p75). Fuente: SERPAVI (Ministerio de Vivienda y Agenda Urbana).")
with right:
    st.subheader("Solicitudes")
    req = query("SELECT programa, anio_convocatoria, solicitudes, aceptadas FROM solicitudes WHERE ine = ? "
                "ORDER BY programa DESC, anio_convocatoria", (r["ine"],))
    if req.empty:
        st.caption("No hay solicitudes de este municipio en los datos abiertos.")
    else:
        st.dataframe(req.assign(programa=req["programa"].map(PROGRAMMES)), hide_index=True, width="stretch",
                     column_config={"programa": "Programa", "anio_convocatoria": st.column_config.NumberColumn(
                         "Año", format="%d"), "solicitudes": "Solicitudes", "aceptadas": "Aceptadas"})
        st.caption("Del Portal de Datos Abiertos de la Comunidad de Madrid. Las Ayudas para jóvenes tienen los mismos "
                   "topes que el Bono.")

st.subheader("El límite de ingresos y el reparto")
with st.container(horizontal=True, key="ficha_ingresos"):  # key: only for the gauges (end of this page)
    st.metric("Declaraciones del IRPF por debajo de 3 × IPREM (2024)", pct(r["share_irpf_bajo_3iprem_2024"]),
              border=True, height="stretch",
              help="Parte de las declaraciones con base imponible de hasta 25.200 €, de todas las edades: compara "
                   "municipios, no cuenta jóvenes.")
    st.metric("Ídem, por debajo de 5 × IPREM: el límite del Plan", pct(r["share_irpf_bajo_5iprem_2024"]),
              border=True, height="stretch",
              help="Base imponible de hasta 42.000 €. El Plan 2026-2030 mira los ingresos de la persona, no los del "
                   "hogar (art. 133.1.d).")
    st.metric("Bonos con la regla de hoy (simulación)", es(r["bonos_actual_2024_55"]), border=True, height="stretch",
              help="5.300 bonos (31,8 M€) por orden de llegada, con los topes de 2024.")
    delta = r["bonos_propuesta"] - r["bonos_actual_2024_55"]
    st.metric("Bonos con la propuesta (simulación)", es(r["bonos_propuesta"]),
              delta=None if np.isnan(delta) else es(delta), border=True, height="stretch",
              help="El mismo dinero, con topes del Plan o del alquiler local (hasta 1.000 €) y cupos por jóvenes × "
                   "necesidad × parte por debajo del límite de ingresos.")
st.caption(SOURCE + " Simulación con β = −0,54 (solo la parte del efecto que se debe al tope); ver «Método y datos».")


def gauge(key, n, share, colour):
    """26-nov: a thin bar at the foot of the n-th figure of a row, as long as the figure itself (0 to 1). Drawn inside the
    card's own bottom padding, so the cards keep their height and nothing below them moves."""
    if share != share:  # NaN: no bar
        return ""
    card = f".st-key-{key} [data-testid='stElementContainer']:nth-child({n}) > [data-testid='stMetric']"
    return (f"{card} {{position: relative;}} {card}::before, {card}::after {{content: ''; position: absolute; left: 1rem;"
            f" bottom: .55rem; height: 6px; border-radius: 999px;}} {card}::before {{right: 1rem;"
            f" background: rgba(128, 128, 128, .17);}} {card}::after {{width: calc((100% - 2rem) * "
            f"{max(0.0, min(1.0, float(share))):.4f}); background: {colour};}}")


# at the end of the page, so this style takes no room above the blocks of the demo
st.html("<style>" + gauge("ficha_cifras", 1, r["indice_necesidad"] / 100, LEVEL[level][1] if level else SLOT1)
        + f".st-key-ficha_cifras [data-testid='stElementContainer']:nth-child(1) > [data-testid='stMetric'] "
          f"{{border-left: 5px solid {LEVEL[level][1] if level else '#2563eb'};}}"
        + gauge("ficha_ingresos", 1, r["share_irpf_bajo_3iprem_2024"], SLOT1)
        + gauge("ficha_ingresos", 2, r["share_irpf_bajo_5iprem_2024"], SLOT1) + "</style>")
